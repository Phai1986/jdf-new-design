module.exports = {
  // debug: true,
  i18n: {
    defaultLocale: 'th',
    locales: ['th', 'en'],
  },
}
