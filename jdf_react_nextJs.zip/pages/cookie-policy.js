import { Redirect } from '../lib/redirect'
export default Redirect
